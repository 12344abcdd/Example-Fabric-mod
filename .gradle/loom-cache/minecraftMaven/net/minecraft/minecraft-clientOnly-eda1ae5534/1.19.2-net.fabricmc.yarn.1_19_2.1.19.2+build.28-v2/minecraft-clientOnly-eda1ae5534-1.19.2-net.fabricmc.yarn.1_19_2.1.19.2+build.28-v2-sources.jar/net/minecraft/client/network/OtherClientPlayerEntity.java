package net.minecraft.client.network;

import com.mojang.authlib.GameProfile;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.network.encryption.PlayerPublicKey;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

/**
 * Represents a player entity that is present on the client but is not the client's own player.
 */
@Environment(EnvType.CLIENT)
public class OtherClientPlayerEntity extends AbstractClientPlayerEntity {
	public OtherClientPlayerEntity(ClientWorld clientWorld, GameProfile gameProfile, @Nullable PlayerPublicKey playerPublicKey) {
		super(clientWorld, gameProfile, playerPublicKey);
		this.stepHeight = 1.0F;
		this.noClip = true;
	}

	public boolean shouldRender(double distance) {
		double d = this.getBoundingBox().getAverageSideLength() * 10.0;
		if (Double.isNaN(d)) {
			d = 1.0;
		}

		d *= 64.0 * getRenderDistanceMultiplier();
		return distance < d * d;
	}

	public boolean damage(DamageSource source, float amount) {
		return true;
	}

	public void tick() {
		super.tick();
		this.updateLimbs(this, false);
	}

	public void tickMovement() {
		if (this.bodyTrackingIncrements > 0) {
			double d = this.getX() + (this.serverX - this.getX()) / this.bodyTrackingIncrements;
			double e = this.getY() + (this.serverY - this.getY()) / this.bodyTrackingIncrements;
			double f = this.getZ() + (this.serverZ - this.getZ()) / this.bodyTrackingIncrements;
			this.setYaw(this.getYaw() + (float)MathHelper.wrapDegrees(this.serverYaw - this.getYaw()) / this.bodyTrackingIncrements);
			this.setPitch(this.getPitch() + (float)(this.serverPitch - this.getPitch()) / this.bodyTrackingIncrements);
			this.bodyTrackingIncrements--;
			this.setPosition(d, e, f);
			this.setRotation(this.getYaw(), this.getPitch());
		}

		if (this.headTrackingIncrements > 0) {
			this.headYaw = this.headYaw + (float)(MathHelper.wrapDegrees(this.serverHeadYaw - this.headYaw) / this.headTrackingIncrements);
			this.headTrackingIncrements--;
		}

		this.prevStrideDistance = this.strideDistance;
		this.tickHandSwing();
		float g;
		if (this.onGround && !this.isDead()) {
			g = (float)Math.min(0.1, this.getVelocity().horizontalLength());
		} else {
			g = 0.0F;
		}

		this.strideDistance = this.strideDistance + (g - this.strideDistance) * 0.4F;
		this.world.getProfiler().push("push");
		this.tickCramming();
		this.world.getProfiler().pop();
	}

	protected void updatePose() {
	}

	public void sendMessage(Text message) {
		MinecraftClient minecraftClient = MinecraftClient.getInstance();
		minecraftClient.inGameHud.getChatHud().addMessage(message);
	}
}
