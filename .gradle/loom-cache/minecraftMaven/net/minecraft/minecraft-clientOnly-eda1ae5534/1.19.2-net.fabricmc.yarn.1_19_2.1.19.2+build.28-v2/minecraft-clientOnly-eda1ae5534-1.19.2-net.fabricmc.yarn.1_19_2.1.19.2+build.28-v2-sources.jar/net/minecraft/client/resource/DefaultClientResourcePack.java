package net.minecraft.client.resource;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Collection;
import java.util.function.Predicate;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.resource.DefaultResourcePack;
import net.minecraft.resource.ResourceType;
import net.minecraft.resource.metadata.PackResourceMetadata;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class DefaultClientResourcePack extends DefaultResourcePack {
	private final ResourceIndex index;

	public DefaultClientResourcePack(PackResourceMetadata metadata, ResourceIndex index) {
		super(metadata, new String[]{"minecraft", "realms"});
		this.index = index;
	}

	@Nullable
	protected InputStream findInputStream(ResourceType type, Identifier id) {
		if (type == ResourceType.CLIENT_RESOURCES) {
			File file = this.index.getResource(id);
			if (file != null && file.exists()) {
				try {
					return new FileInputStream(file);
				} catch (FileNotFoundException var5) {
				}
			}
		}

		return super.findInputStream(type, id);
	}

	public boolean contains(ResourceType type, Identifier id) {
		if (type == ResourceType.CLIENT_RESOURCES) {
			File file = this.index.getResource(id);
			if (file != null && file.exists()) {
				return true;
			}
		}

		return super.contains(type, id);
	}

	@Nullable
	protected InputStream getInputStream(String path) {
		File file = this.index.findFile(path);
		if (file != null && file.exists()) {
			try {
				return new FileInputStream(file);
			} catch (FileNotFoundException var4) {
			}
		}

		return super.getInputStream(path);
	}

	public Collection<Identifier> findResources(ResourceType type, String namespace, String prefix, Predicate<Identifier> allowedPathPredicate) {
		Collection<Identifier> collection = super.findResources(type, namespace, prefix, allowedPathPredicate);
		collection.addAll(this.index.getFilesRecursively(prefix, namespace, allowedPathPredicate));
		return collection;
	}
}
