package net.minecraft;

import java.util.Date;
import net.minecraft.resource.ResourceType;

/**
 * The game version interface used by Minecraft, replacing the javabridge
 * one's occurrences in Minecraft code.
 */
public interface GameVersion {
	SaveVersion dataVersion();

	String id();

	String name();

	int protocolVersion();

	int packVersion(ResourceType type);

	Date buildTime();

	boolean stable();

	public record Impl(
		String id, String name, SaveVersion dataVersion, int protocolVersion, int resourcePackVersion, int datapackVersion, Date buildTime, boolean stable
	) implements GameVersion {
		@Override
		public int packVersion(ResourceType type) {
			return switch (type) {
				case CLIENT_RESOURCES -> this.resourcePackVersion;
				case SERVER_DATA -> this.datapackVersion;
			};
		}
	}
}
