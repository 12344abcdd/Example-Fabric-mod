package net.minecraft.command;

public interface PermissionLevelSource {
	boolean hasPermissionLevel(int level);

	default boolean hasElevatedPermissions() {
		return this.hasPermissionLevel(2);
	}

	public record PermissionLevelSourcePredicate<T extends PermissionLevelSource>(int requiredLevel) implements PermissionLevelPredicate<T> {
		public boolean test(T permissionLevelSource) {
			return permissionLevelSource.hasPermissionLevel(this.requiredLevel);
		}
	}
}
